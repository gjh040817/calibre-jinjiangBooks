# 在含有 calibre dev 测试脚本环境下运行（示例，仅供参考）
import re
import time
import random
import gzip
import json
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from queue import Queue, Empty
from urllib.parse import urlparse, unquote, urlencode, parse_qs
from urllib.request import Request, urlopen
import ssl

from calibre import random_user_agent
from calibre.ebooks.metadata import check_isbn
from calibre.ebooks.metadata.book.base import Metadata
from calibre.ebooks.metadata.sources.base import Source, Option
from lxml import etree

try:
    from html2text import html2text as _html2text
except Exception:
    _html2text = None


# 简单回退：确保 `_()` 在非 Calibre 环境下也可用，避免语法/编译期错误
try:
    _
except NameError:
    def _(s):
        return s


def html_to_text(html: str) -> str:
    """将 HTML 转为纯文本，优先使用 html2text，回退为简单的标签剥离。"""
    if not html:
        return ''
    if _html2text:
        try:
            return _html2text(html).strip()
        except Exception:
            pass
    # 简单回退：移除标签并压缩空白
    txt = re.sub(r'<[^>]+>', '', html)
    txt = re.sub(r'\s+', ' ', txt).strip()
    return txt


def normalize_query(s: str) -> str:
    """简单清洗搜索关键词：
    - 全角转半角
    - 去除括号内注记（例如：(hp)，（hp））
    - 把中文标点转换为英文标点（句号、中点等）
    - 删除不可见/特殊字符
    - 合并多余空格
    """
    if not s:
        return s
    # 全角->半角
    def full2half(u):
        res = []
        for ch in u:
            code = ord(ch)
            if code == 0x3000:
                res.append(' ')
            elif 0xFF01 <= code <= 0xFF5E:
                res.append(chr(code - 0xFEE0))
            else:
                res.append(ch)
        return ''.join(res)

    s = full2half(s)

    # 去除括号内内容（中英文括号）
    s = re.sub(r"\([^\)]*\)", '', s)
    s = re.sub(r"\[[^\]]*\]", '', s)
    s = re.sub(r"（[^）]*）", '', s)
    s = re.sub(r"【[^】]*】", '', s)

    # 替换特殊分隔符、中文中点等为空格或标准符号
    s = s.replace('·', ' ').replace('•', ' ').replace('・', ' ').replace('\u2026', ' ')
    s = s.replace('：', ':').replace('。', '.').replace('，', ',')

    # 删除非字母数字和常见中日韩文字及标点之外的特殊字符
    s = re.sub(r"[^\w\u4e00-\u9fff\u3000-\u303F\-\.:,' ]+", ' ', s)

    # 合并空格并去掉首尾
    s = re.sub(r"\s+", ' ', s).strip()
    return s


def generate_title_variations(cleaned_title: str):
    """基于清洗后的 title 生成若干简短变体，按优先级返回：
    - 去掉常见标注词（完结、番外等）
    - 若仍无结果，按空格分词，尝试更短的关键词（最长词先）
    """
    if not cleaned_title:
        return []

    variations = []
    # 去掉常见标注词
    stopwords = ['完结', '完本', '连载', '番外', '全本', 'txt', '全文', '番外篇']
    short = cleaned_title
    for w in stopwords:
        short = short.replace(w, ' ')
    short = re.sub(r"\s+", ' ', short).strip()
    if short and short != cleaned_title:
        variations.append(short)

    # 按词长度降序尝试关键单词
    tokens = [t for t in re.split(r"\s+", cleaned_title) if t]
    tokens = sorted(tokens, key=lambda x: len(x), reverse=True)
    for t in tokens[:5]:
        if len(t) >= 2 and t not in variations:
            variations.append(t)

    return variations

# 晋江核心配置（融合JSON接口和网页结构）
JINJIANG_BASE_URL = "https://www.jjwxc.net/"
JINJIANG_M_BASE_URL = "https://m.jjwxc.net/"  # 移动端
JINJIANG_APP_BASE_URL = "https://app.jjwxc.org/"  # APP接口域名
JINJIANG_SEARCH_WEB_URL = "https://www.jjwxc.net/search.php"  # 网页搜索
JINJIANG_SEARCH_APP_URL = "https://app.jjwxc.org/search/searchV3"  # APP搜索接口（更稳定）
JINJIANG_SEARCH_APP_ANDROID_API = "https://app.jjwxc.org/androidapi/search"  # Android API 搜索（参考 JS 规则）
JINJIANG_BOOK_DETAIL_WEB_URL = "https://www.jjwxc.net/onebook.php?novelid=%s"  # 网页详情页
JINJIANG_BOOK_DETAIL_APP_URL = "https://app.jjwxc.org/androidapi/getBookDetail"  # APP详情接口
JINJIANG_BOOK_ID_PATTERN = re.compile(r"novelid=(\d+)")
PROVIDER_NAME = "Jinjiang Books (Enhanced)"
PROVIDER_ID = "jinjiang_enhanced"
PROVIDER_VERSION = (1, 2, 0)
PROVIDER_AUTHOR = 'Your Name'

# 并发查询数
JINJIANG_CONCURRENCY_SIZE = 5

# 搜索类型映射（对应JSON中的搜索规则）
SEARCH_TYPE_MAP = {
    "book": 1,    # 书名（默认）
    "author": 2,  # 作者（JSON：#关键词#）
    "protagonist": 4,  # 主角（JSON：主角#关键词#）
    "supporting": 5,   # 配角（JSON：配角#关键词#）
    "other": 6,    # 其他关键字（JSON：其他#关键词#）
    "id": 7        # 作品ID（JSON：ID#关键词#）
}

# 已移除榜单功能：不再维护分类榜单常量


class JinjiangBookSearcher:
    def __init__(self, *args, **kwargs):
        """
        兼容性构造函数：接受多种命名的并发参数（concurrency_size 或 max_workers），
        以及插件选项的命名参数（jinjiang_delay_enable 等）。
        这样可避免 Calibre 或其它地方传入不同关键字时报错。
        """
        # 支持位置参数兼容（参考豆瓣实现）：
        # JinjiangBookSearcher(max_workers, jinjiang_delay_enable, jinjiang_login_cookie)
        pos_max_workers = args[0] if len(args) > 0 else None
        pos_delay = args[1] if len(args) > 1 else None
        pos_cookie = args[2] if len(args) > 2 else None

        # 并发参数：优先使用 kwargs 中的 concurrency_size，再尝试 max_workers，最后回退到位置参数或默认常量
        concurrency = kwargs.pop('concurrency_size', None)
        if concurrency is None:
            concurrency = kwargs.pop('max_workers', None)
        if concurrency is None:
            concurrency = pos_max_workers
        try:
            self.max_workers = int(concurrency) if concurrency is not None else JINJIANG_CONCURRENCY_SIZE
        except Exception:
            self.max_workers = JINJIANG_CONCURRENCY_SIZE

        # 其余选项（带默认值）。如果提供了位置参数则作为回退。
        self.jinjiang_delay_enable = kwargs.pop('jinjiang_delay_enable', pos_delay if pos_delay is not None else True)
        self.jinjiang_login_cookie = kwargs.pop('jinjiang_login_cookie', pos_cookie if pos_cookie is not None else None)
        self.jinjiang_search_with_author = kwargs.pop('jinjiang_search_with_author', False)
        self.jinjiang_prefer_app_api = kwargs.pop('jinjiang_prefer_app_api', True)

        # 初始化解析器与线程池
        self.book_parser = JinjiangBookHtmlParser()
        # 限制线程数避免误设置过大
        max_workers_safe = max(1, min(self.max_workers, 20))
        self.thread_pool = ThreadPoolExecutor(max_workers=max_workers_safe, thread_name_prefix='jinjiang_async')

        # 从Cookie提取 sid（用于 APP 接口）
        self.sid = self.extract_sid_from_cookie()

    def extract_sid_from_cookie(self):
        """从Cookie中提取sid（APP接口需要的认证参数）"""
        if not self.jinjiang_login_cookie:
            return None

        c = self.jinjiang_login_cookie
        # 1) 优先查找 sid=
        m = re.search(r"sid=([^;\s]+)", c)
        if m:
            return m.group(1)

        # 2) 再查找 token= 或 bbstoken=
        m = re.search(r"token=([^;\s]+)", c)
        if m:
            return unquote(m.group(1))
        m = re.search(r"bbstoken=([^;\s]+)", c)
        if m:
            return unquote(m.group(1))

        # 3) 有时 sid 会在 JJSESS 之类的 cookie 的 JSON 字段中，例如 JJSESS contains sidkey
        m = re.search(r"JJSESS=([^;]+)", c)
        if m:
            raw = unquote(m.group(1))
            try:
                # 尝试解析为 JSON
                j = json.loads(raw)
                if isinstance(j, dict):
                    for key in ('sid', 'sidkey', 'token'):
                        if key in j and j[key]:
                            return j[key]
            except Exception:
                # 不是 JSON 的话尝试从字符串中抓 sidkey
                m2 = re.search(r"sidkey\W*[:=]\W*'?\"?([\w-]+)'?\"?", raw)
                if m2:
                    return m2.group(1)

        # 4) fallback: 尝试找其他常见字段
        m = re.search(r"JJEVER=([^;\s]+)", c)
        if m:
            # JJEVER 有时包含用户信息，但不是直接 sid；不做进一步解析
            return None

        return None

    def parse_search_keyword(self, query):
        """解析搜索关键词（适配JSON中的特殊规则）"""
        search_type = SEARCH_TYPE_MAP["book"]  # 默认搜索书名

        if not query:
            return query, search_type

        q = query.strip()

        # 支持 URL/参数形式：t=2 或 type=2 开头的写法，例如: "t=2 我喜欢你的信息素"
        m = re.match(r'^(?:t|type)\s*[:=]\s*(\d+)\s*(.*)$', q, re.I)
        if m:
            try:
                tnum = int(m.group(1))
                rest = m.group(2).strip()
                if tnum in SEARCH_TYPE_MAP.values():
                    return (rest or query, tnum)
            except Exception:
                pass

        # 支持中文/英文前缀形式：作者:xxx, author:xxx, 主角:xxx, 配角:xxx, 其它:xxx, ID:xxx
        m = re.match(r'^(?:作者|author)\s*[:：]\s*(.+)$', q, re.I)
        if m:
            return m.group(1).strip(), SEARCH_TYPE_MAP['author']

        m = re.match(r'^(?:主角|protagonist)\s*[:：]\s*(.+)$', q, re.I)
        if m:
            return m.group(1).strip(), SEARCH_TYPE_MAP['protagonist']

        m = re.match(r'^(?:配角|supporting)\s*[:：]\s*(.+)$', q, re.I)
        if m:
            return m.group(1).strip(), SEARCH_TYPE_MAP['supporting']

        m = re.match(r'^(?:其它|其他|other)\s*[:：]\s*(.+)$', q, re.I)
        if m:
            return m.group(1).strip(), SEARCH_TYPE_MAP['other']

        m = re.match(r'^(?:ID|文章ID|id)\s*[:：]\s*(.+)$', q, re.I)
        if m:
            return m.group(1).strip(), SEARCH_TYPE_MAP['id']

        # 保留原有的 #...# 规则（例如 #作者# 表示按作者搜索）
        if q.startswith("#") and q.endswith("#"):
            inner = q.strip("#").strip()
            return inner, SEARCH_TYPE_MAP['author']
        elif q.startswith("主角#") and q.endswith("#"):
            inner = q[len("主角#"):-1].strip()
            return inner, SEARCH_TYPE_MAP['protagonist']
        elif q.startswith("配角#") and q.endswith("#"):
            inner = q[len("配角#"):-1].strip()
            return inner, SEARCH_TYPE_MAP['supporting']
        elif q.startswith("其他#") and q.endswith("#"):
            inner = q[len("其他#"):-1].strip()
            return inner, SEARCH_TYPE_MAP['other']
        elif q.startswith("ID#") and q.endswith("#"):
            inner = q[len("ID#"):-1].strip()
            return inner, SEARCH_TYPE_MAP['id']

        return query, search_type

    def search_via_app_api(self, query, search_type, log):
        """通过APP搜索接口获取书籍（更稳定，反爬弱）"""
        book_urls = []
        if not self.sid:
            log.warning("APP接口需要登录Cookie（含sid），切换到网页搜索")
            return book_urls
        # 先尝试更稳定的 searchV3 接口（在脚本中这个接口更可靠），再回退到 androidapi/search
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        tried = []

        # helper to parse common response shapes
        def _extract_books_from_json(data):
            books_list = []
            if not data:
                return books_list
            # 兼容多种结构
            if isinstance(data, dict):
                # { code:0, data: { books: [...] } } 或 { items: [...] } 或 { data: { items: [...] } }
                if data.get('code') == 0 and data.get('data'):
                    d = data.get('data')
                    # data 可能包含多种 key
                    books_list = d.get('books') or d.get('results') or d.get('items') or d.get('list') or []
                else:
                    # 直接查找若干常见键
                    books_list = data.get('books') or data.get('results') or data.get('items') or data.get('list') or []
            elif isinstance(data, list):
                books_list = data
            return books_list

        # 1) 优先 searchV3
        try:
            params = {'keyword': query, 'type': search_type, 'page': 1}
            if self.sid:
                params['token'] = self.sid
            url = JINJIANG_SEARCH_APP_URL + '?' + urlencode(params)
            tried.append(url)
            log.info(f"Trying APP searchV3 URL: {url}")
            res = urlopen(Request(url, headers=self.get_headers(), method='GET'), timeout=15, context=ctx)
            if res.status in (200, 201):
                content = self.get_res_content(res)
                try:
                    data = json.loads(content)
                except Exception:
                    data = None
                books = _extract_books_from_json(data)
                if books:
                    for book in books:
                        novelid = book.get('novelid') or book.get('bookId') or book.get('id')
                        if novelid and len(book_urls) < self.max_workers:
                            detail_url = JINJIANG_BOOK_DETAIL_WEB_URL % novelid
                            book_urls.append(detail_url)
                            log.info(f"searchV3 found book: {book.get('bookname') or book.get('title')} (ID: {novelid})")
                    return book_urls
                else:
                    log.debug('searchV3 returned no books')
        except Exception as e:
            log.debug(f"searchV3 request failed: {e}")

        # 2) 回退到 androidapi/search
        try:
            params = {'versionCode': 282, 'keyword': query, 'type': search_type, 'page': 1}
            if self.sid:
                params['token'] = self.sid
            url2 = JINJIANG_SEARCH_APP_ANDROID_API + '?' + urlencode(params)
            tried.append(url2)
            log.info(f"APP androidapi search URL: {url2}")
            res2 = urlopen(Request(url2, headers=self.get_headers(), method='GET'), timeout=15, context=ctx)
            if res2.status in (200, 201):
                content2 = self.get_res_content(res2)
                try:
                    data2 = json.loads(content2)
                except Exception:
                    data2 = None
                books2 = _extract_books_from_json(data2)
                if books2:
                    for book in books2:
                        novelid = book.get('novelid') or book.get('bookId') or book.get('id')
                        if novelid and len(book_urls) < self.max_workers:
                            detail_url = JINJIANG_BOOK_DETAIL_WEB_URL % novelid
                            book_urls.append(detail_url)
                            log.info(f"androidapi found book: {book.get('bookname') or book.get('title')} (ID: {novelid})")
                    return book_urls
                else:
                    log.debug('androidapi returned no books')
                    # 把响应内容写入日志（前2000字符），便于诊断
                    try:
                        snippet = (content2 or '')[:2000]
                        log.debug(f"androidapi response snippet: {snippet}")
                    except Exception:
                        pass
        except Exception as e:
            log.debug(f"androidapi request failed: {e}")

        # 若都未命中，记录尝试过的 URL 以便排查
        if tried:
            log.debug(f"Tried APP search URLs: {', '.join(tried)}")

        return book_urls

    def search_via_web(self, query, search_type, log):
        # 网页搜索功能已移除，插件仅使用 APP 接口进行搜索
        log.debug('search_via_web called but web search has been removed; returning empty list')
        return []

    def load_book_urls_new(self, query, log):
        """统一搜索入口：优先APP接口，失败则切换网页"""
        # 解析关键词和搜索类型
        query, search_type = self.parse_search_keyword(query)
        log.info(f"Search query: {query}, type: {search_type} ({[k for k,v in SEARCH_TYPE_MAP.items() if v==search_type][0]})")
        # 仅使用 APP 接口（不再使用网页搜索）
        book_urls = self.search_via_app_api(query, search_type, log)
        if not book_urls:
            log.info('APP接口未返回结果')
        return book_urls

    def search_books(self, query, authors, log):
        """搜索书籍（支持带作者搜索）"""
        if self.jinjiang_search_with_author and authors:
            author_str = ' '.join(authors)
            query = f'{query} {author_str}'
            log.info(f"Enhanced search query: {query}")
        
        book_urls = self.load_book_urls_new(query, log)
        books = []
        futures = [self.thread_pool.submit(self.load_book, url, log) for url in book_urls]
        
        for future in as_completed(futures):
            try:
                book = future.result()
                if book:
                    books.append(book)
            except Exception as e:
                log.error(f"Future error: {e}")
        
        return books

    # 榜单/发现类功能已完全移除以简化插件行为（仅保留按书名/作者的识别与封面下载）

    def extract_novelid(self, href):
        """提取novelid（支持APP和网页链接）"""
        if not href:
            return None
        params = parse_qs(urlparse(href).query)
        novelids = params.get('novelid', [])
        if novelids:
            return novelids[0]
        # 适配APP接口的bookId参数
        book_ids = params.get('bookId', [])
        return book_ids[0] if book_ids else None

    def build_book_detail_url(self, novelid):
        """构建书籍详情页URL"""
        return JINJIANG_BOOK_DETAIL_WEB_URL % novelid

    def load_book(self, url, log):
        """下载并解析书籍详情（优先APP接口，失败则网页）"""
        book = None
        start_time = time.time()
        if self.jinjiang_delay_enable:
            self.random_sleep(log)
        
        # 提取novelid
        novelid = self.extract_novelid(url)
        if not novelid:
            log.error(f"Cannot extract novelid from URL: {url}")
            return None
        
        # 优先使用APP详情接口（数据更结构化）
        if self.jinjiang_prefer_app_api and self.sid:
            book = self.load_book_via_app_api(novelid, log)
            if book:
                elapsed = (time.time() - start_time) * 1000
                log.info(f"APP API loaded book: {book['title']} (time: {elapsed:.0f}ms)")
                return book
            log.info(f"APP detail API failed, fallback to web page: {url}")
        
        # 网页详情页兜底
        try:
            res = urlopen(Request(url, headers=self.get_headers(), method='GET'), timeout=10)
            if res.status in [200, 201]:
                elapsed = (time.time() - start_time) * 1000
                log.info(f"Web loaded book: {url} (time: {elapsed:.0f}ms)")
                book_detail_content = self.get_res_content(res)
                book = self.book_parser.parse_book(url, book_detail_content, log)
        except Exception as e:
            log.error(f"Web load book failed: {e}")
        
        return book

    def fetch_and_merge_other_info(self, novelid, book, log=None, base_data=None):
        """从 APP 的 getnovelOtherInfo 接口获取扩展信息并合并到 book 的 description 字段中。

        目的字段包括：文章类型、全文字数、非V点击、文章积分、签约状态、收藏数/排名、营养/评分、简介拓展、标签、主/配/其它角色、风格/视角/系列、留言等。
        错误不会抛出以免影响主流程，所有异常记录到 log.debug。
        """
        if not novelid:
            return

        try:
            params = {'versionCode': 279, 'novelId': novelid, 'type': 'novelbasicinfo'}
            url = 'https://app.jjwxc.org/androidapi/getnovelOtherInfo' + '?' + urlencode(params)
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            if log:
                log.debug(f'Trying other-info URL: {url}')
            res = urlopen(Request(url, headers=self.get_headers(), method='GET'), timeout=10, context=ctx)
            if res.status not in (200, 201):
                return
            content = self.get_res_content(res)
            try:
                data = json.loads(content)
            except Exception:
                data = None

            # 获取可能的有效对象（兼容多种封装）
            other = None
            if isinstance(data, dict):
                # 常见位置：直接字段或 data/novelLeave 等
                for k in ('data', 'a', 'novelLeave', 'novel', 'result'):
                    if k in data and data[k]:
                        other = data[k]
                        break
                if other is None:
                    other = data
            elif isinstance(data, list) and data:
                other = data[0]
            else:
                other = data

            if not other:
                return

            # 简单键查找器（大小写/下划线不敏感，支持嵌套data->book等）
            def pick(obj, *keys):
                if not obj:
                    return ''
                try:
                    if isinstance(obj, dict):
                        lowmap = {str(k).lower(): k for k in obj.keys()}
                        for k in keys:
                            # 精确或变体
                            if k in obj and obj[k]:
                                return obj[k]
                            lk = k.lower()
                            if lk in lowmap:
                                v = obj.get(lowmap[lk])
                                if v:
                                    return v
                    # 嵌套尝试
                    for nest in ('data', 'a', 'novel', 'result'):
                        nested = obj.get(nest) if isinstance(obj, dict) else None
                        if nested:
                            v = pick(nested, *keys)
                            if v:
                                return v
                    if isinstance(obj, list) and obj:
                        return pick(obj[0], *keys)
                except Exception:
                    return ''
                return ''

            sources = []
            if isinstance(other, dict):
                sources.append(other)
            if isinstance(base_data, dict):
                sources.append(base_data)
            if isinstance(book, dict):
                sources.append(book)

            def pick_any(*keys):
                for src in sources:
                    val = pick(src, *keys)
                    if isinstance(val, str):
                        if val.strip():
                            return val.strip()
                    elif val is not None:
                        return val
                return ''

            lines = []

            # 留言/作者留言（novelLeave）
            leave_obj = None
            for src in sources:
                if isinstance(src, dict):
                    for k in ('novelLeave', 'leave', 'novelleave'):
                        if k in src and src[k]:
                            leave_obj = src[k]
                            break
                if leave_obj:
                    break
            leave_display = ''
            if leave_obj:
                try:
                    ld_back = leave_obj.get('leaveDateBack') or leave_obj.get('leave_date_back') or ''
                    ld = leave_obj.get('leaveDate') or leave_obj.get('leaveDateStr') or leave_obj.get('leave_date') or ''
                    lcont = leave_obj.get('leaveContent') or leave_obj.get('leave_content') or ''
                    leave_lines = [str(x) for x in (ld_back, lcont, ld) if x]
                    if leave_lines:
                        leave_display = '\n'.join(leave_lines) + '\n&lrm;\n'
                except Exception:
                    leave_display = ''

            # 文章类型：加入 lines 并合并到 tags
            novel_class = pick_any('novelClass', 'novel_class', 'category')
            if novel_class:
                try:
                    existing_tags = book.get('tags') or []
                    if not isinstance(existing_tags, list):
                        existing_tags = [t.strip() for t in str(existing_tags).split(',') if t.strip()]
                    merged = [novel_class] + [t for t in existing_tags if str(t).strip() and str(t).strip() != str(novel_class).strip()]
                    seen = set()
                    uniq = []
                    for t in merged:
                        if t and t not in seen:
                            seen.add(t)
                            uniq.append(t)
                    book['tags'] = uniq
                except Exception:
                    book['tags'] = [novel_class]

            # 全文字数
            novel_size = pick_any('novelSize', 'novel_size', 'novelSizeShow', 'novelsizeformat', 'word_count', 'words')
            if isinstance(novel_size, (list, dict)):
                try:
                    novel_size = html_to_text(json.dumps(novel_size, ensure_ascii=False))
                except Exception:
                    novel_size = ''

            # 非V点击、积分
            novip_clicks = pick_any('novip_clicks', 'novipClicks', 'novipClick', 'novipclicks')
            novel_score = pick_any('novelScore', 'score', 'novelscore')

            # 签约状态：仅当字段存在时才写入，支持多种表示形式（字符串数字/布尔）
            is_sign = pick_any('isSign', 'is_sign', 'issign')
            signed_display = ''
            try:
                if is_sign is not None and str(is_sign).strip() != '':
                    raw_sign = str(is_sign).strip()
                    signed_flag = False
                    if isinstance(is_sign, bool):
                        signed_flag = bool(is_sign)
                    else:
                        lr = raw_sign.lower()
                        if lr in ('1', 'true', 'yes'):
                            signed_flag = True
                        else:
                            try:
                                if re.match(r'^\d+$', raw_sign) and int(raw_sign) > 0:
                                    signed_flag = True
                            except Exception:
                                signed_flag = False
                    signed_display = '已签约' if signed_flag else '未签约'
                    if log:
                        try:
                            log.debug(f'fetch_and_merge_other_info isSign raw="{raw_sign}" -> {signed_display}')
                        except Exception:
                            pass
            except Exception:
                if log:
                    try:
                        log.debug('Error parsing isSign value')
                    except Exception:
                        pass

            if not signed_display:
                signed_display = '未签约'

            # 收藏/排名/营养
            befav = pick_any('novelbefavoritedcount', 'befavoritedcount', 'favoriteCount')
            nutrition = pick_any('nutrition_novel', 'nutrition', 'nutritionNovel')
            ranking_raw = pick_any('ranking', 'rank', 'ranking_str')
            ranking_number = ''
            if ranking_raw:
                try:
                    m = re.search(r"(\d+)", str(ranking_raw))
                    if m:
                        ranking_number = m.group(1)
                except Exception:
                    ranking_number = ''
            if not befav:
                befav = '0'
            if not ranking_number:
                ranking_number = '暂无排名'
            nutrition_display = str(nutrition) if nutrition else '0'

            # 拓展简介（novelIntro）——映射到 book['comments']，同时也保留到 lines 以供 description 合并
            intro = pick_any('novelIntro', 'novelintro', 'novelIntroShort', 'novelIntroShortHtml', 'description', 'desc')
            if intro:
                intro_txt = html_to_text(str(intro))
                # map to comments (append if exists)
                try:
                    exist_comments = book.get('comments') or ''
                    if exist_comments:
                        book['comments'] = str(exist_comments).strip() + '\n\n' + intro_txt
                    else:
                        book['comments'] = intro_txt
                except Exception:
                    book['comments'] = intro_txt
                intro_txt = intro_txt.replace('立意:', '立意：').replace('立意 :', '立意：')
            # 标签（novelTags）——合并到 book['tags'] 并加入 lines 供描述使用
            tags = pick_any('novelTags', 'novel_tags', 'tags')
            parsed_tags = []
            try:
                if isinstance(tags, str):
                    parsed_tags = [t.strip() for t in re.split(r'[,&/;，、\s]+', tags) if t.strip()]
                elif isinstance(tags, list):
                    parsed_tags = [str(t).strip() for t in tags if str(t).strip()]
            except Exception:
                parsed_tags = []
            tags_line = ''
            if parsed_tags:
                # merge into book['tags'] preserving order and uniqueness
                try:
                    existing_tags = book.get('tags') or []
                    if not isinstance(existing_tags, list):
                        existing_tags = [t.strip() for t in str(existing_tags).split(',') if t.strip()]
                    merged = existing_tags + [t for t in parsed_tags if t not in existing_tags]
                    # dedupe while preserving order
                    seen = set()
                    uniq = []
                    for t in merged:
                        if t and t not in seen:
                            seen.add(t)
                            uniq.append(t)
                    book['tags'] = uniq
                except Exception:
                    book['tags'] = parsed_tags
                tags_line = '标签：' + '&nbsp;'.join(parsed_tags)

            # 主角/配角/其它
            prot = pick_any('protagonist', 'protagonists', '主角')
            costar = pick_any('costar', 'coStar', '配角')
            other_roles = pick_any('other', 'others')
            role_parts = []
            def clean_role(val):
                if not val:
                    return ''
                txt = html_to_text(str(val))
                return re.sub(r'^(主角|配角|其它|其他)[:：]\s*', '', txt)
            prot_clean = clean_role(prot)
            costar_clean = clean_role(costar)
            other_clean = clean_role(other_roles)
            if prot_clean:
                role_parts.append(f'主角：{prot_clean}')
            if costar_clean:
                role_parts.append(f'配角：{costar_clean}')
            if other_clean:
                role_parts.append(f'其它：{other_clean}')
            roles_comb = ''.join(role_parts)

            # 风格/视角/系列（保持与参考模板一致的布局）
            style = pick_any('novelStyle', 'style')
            mainview = pick_any('mainview', 'view')
            series = pick_any('series')
            style_line = f"风格：{style or ''}&nbsp;&nbsp;&nbsp;&nbsp;视角：{mainview or ''}" if (style or mainview) else ''
            series_line = f'所属：{series}' if series else ''

            # 构建最终描述块，参考提供的模板
            first_line = (leave_display or '') + (f"文章类型：{novel_class}" if novel_class else '')
            if first_line:
                lines.append(first_line)
            elif leave_display:
                lines.append(leave_display.rstrip('\n'))

            if novel_size:
                lines.append(f'全文字数：{novel_size}')
            if novip_clicks:
                lines.append(f'非V点击：{novip_clicks}')
            if novel_score:
                lines.append(f'文章积分：{novel_score}')
            if signed_display:
                lines.append(f'签约状态：{signed_display}')

            lines.append('&lrm;')
            lines.append(f'⭐&nbsp;{befav}丨👍&nbsp;No.{ranking_number}丨🍼&nbsp;{nutrition_display}')
            lines.append('&lrm;')

            if intro and intro_txt:
                lines.append(intro_txt)
                lines.append('&lrm;')

            if tags_line:
                lines.append(tags_line)
            if roles_comb:
                lines.append(roles_comb)
            if style_line:
                lines.append(style_line)
            if series_line:
                lines.append(series_line)

            # 移除原先注入到描述中的前端 JS 处理提示，避免在 Calibre 简介中出现杂项文本

            # 把 lines 合并到 description 字段（HTML + 纯文本）
            if lines:
                extra_html = '<br>'.join([str(x).replace('\n', '<br>') for x in lines])
                extra_text = '\n'.join([str(x) for x in lines])
                # 合并到已有简介
                try:
                    exist_html = book.get('description_html') or book.get('description') or ''
                    if exist_html:
                        book['description_html'] = str(exist_html) + '<br><br>' + extra_html
                    else:
                        book['description_html'] = extra_html
                except Exception:
                    book['description_html'] = extra_html
                try:
                    exist_txt = book.get('description') or ''
                    if exist_txt:
                        book['description'] = str(exist_txt) + '\n\n' + extra_text
                    else:
                        book['description'] = extra_text
                except Exception:
                    book['description'] = extra_text

        except Exception as e:
            if log:
                try:
                    log.debug(f'fetch_and_merge_other_info error: {e}')
                except Exception:
                    pass
            return


    def load_book_via_app_api(self, novelid, log):
        """通过 APP 详情接口获取书籍数据（多端兼容）：
        尝试多个已知的详情接口和参数名（novelid/bookId/novelId），并兼容不同的返回结构。
        如果某个接口返回可用的 JSON，则解析并返回 book dict，否则返回 None。
        """
        # candidate detail endpoints (try CDN first, then main app host)
        detail_endpoints = [
            # observed working endpoint in lightweight clients
            'https://app-cdn.jjwxc.net/androidapi/novelbasicinfo',
            # fallback endpoints
            JINJIANG_BOOK_DETAIL_APP_URL,
            'https://app.jjwxc.org/androidapi/novelbasicinfo'
        ]

        # SSL context: allow disabling verification for app hosts to avoid local cert issues
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        tried = []

        # try multiple parameter name variants
        param_variants = [
            {'novelid': novelid},
            {'novelId': novelid},
            {'bookId': novelid},
            {'bookid': novelid}
        ]

        # include token/version/platform where useful
        for endpoint in detail_endpoints:
            for base_params in param_variants:
                params = dict(base_params)
                # attach optional token and client info if available
                if self.sid:
                    params['token'] = self.sid
                params.setdefault('version', '9.9.9')
                params.setdefault('platform', 'android')

                url = endpoint + '?' + urlencode(params)
                tried.append(url)
                try:
                    log.debug(f'Trying APP detail URL: {url}')
                    res = urlopen(Request(url, headers=self.get_headers(), method='GET'), timeout=15, context=ctx)
                    if res.status not in (200, 201):
                        continue
                    content = self.get_res_content(res)
                    # try parse JSON
                    try:
                        data = json.loads(content)
                    except Exception:
                        data = None

                    if not data:
                        # some endpoints may return directly the object or wrap under 'data' or 'items'
                        try:
                            # attempt to find JSON-like substring
                            j = json.loads(content.strip())
                            data = j
                        except Exception:
                            data = None

                    if data:
                        # common patterns: { code:0, data: { ... } } or { data: { book: ... } } or { items: [...] }
                        app_data = None
                        if isinstance(data, dict):
                            if data.get('code') == 0 and data.get('data'):
                                d = data.get('data')
                                # if 'book' key present inside data, use it
                                if isinstance(d, dict) and (d.get('book') or d.get('novel')):
                                    app_data = d.get('book') or d.get('novel') or d
                                else:
                                    app_data = d
                            elif data.get('data') and isinstance(data.get('data'), dict):
                                app_data = data.get('data')
                            elif data.get('items'):
                                # items list - pick first item that matches novelid
                                items = data.get('items')
                                if isinstance(items, list) and items:
                                    # find matching item by novelid/bookId if present
                                    found = None
                                    for it in items:
                                        try:
                                            if str(it.get('novelid') or it.get('bookId') or it.get('id')) == str(novelid):
                                                found = it
                                                break
                                        except Exception:
                                            continue
                                    app_data = found or items[0]
                            else:
                                # sometimes the top-level dict is already the book data
                                app_data = data
                        elif isinstance(data, list) and data:
                            # list of books
                            app_data = data[0]

                        if app_data:
                            try:
                                parsed = self.parse_app_book_data(app_data, novelid, log)
                                # 验证解析结果：若关键字段缺失（书名/作者），视为解析失败以触发回退
                                title_ok = bool(parsed.get('title'))
                                authors_ok = bool(parsed.get('authors'))
                                if not title_ok or not authors_ok:
                                    log.debug(f'APP detail parsed but missing title/authors for {novelid}, will fallback to web')
                                else:
                                    return parsed
                            except Exception as e:
                                log.debug(f'parse_app_book_data failed: {e}')
                except Exception as e:
                    log.debug(f'APP detail request to {url} failed: {e}')

        log.debug(f'Tried APP detail URLs: {tried}')
        return None

    def parse_app_book_data(self, app_data, novelid, log=None):
        """解析APP接口返回的JSON数据；增强兼容性：
        - 支持驼峰/下划线/大小写变体
        - 支持在常见嵌套字段（book/novel/data/items[0]）中查找
        - 使用 html_to_text 清洗 HTML
        - 当关键字段缺失时尝试记录原始 JSON 到桌面 debug 文件（便于排查）
        """
        book = {}
        book['id'] = novelid

        # 生成候选 key 变体
        def key_variants(k):
            vs = set()
            if not k:
                return vs
            vs.add(k)
            vs.add(k.lower())
            # 驼峰/下划线互转
            vs.add(''.join([p.capitalize() if i>0 else p for i,p in enumerate(k.split('_'))]))
            vs.add(k.replace('_', ''))
            vs.add(k.replace('_', '').lower())
            vs.add(k.replace(' ', ''))
            # 常见驼峰小写首字母
            if '_' in k:
                parts = k.split('_')
                camel = parts[0] + ''.join([p.capitalize() for p in parts[1:]])
                vs.add(camel)
            return vs

        # 从一个 dict 中递归查找首个非空值（只向下一层嵌套寻找）
        def _pick_from(obj, *keys):
            if not obj or not keys:
                return ''
            # 先尝试直接或变体键
            try:
                for k in keys:
                    for cand in key_variants(k):
                        if isinstance(obj, dict) and cand in obj and obj[cand]:
                            return obj[cand]
                # 再尝试不精确匹配（忽略大小写）
                if isinstance(obj, dict):
                    lowmap = {str(kk).lower(): kk for kk in obj.keys()}
                    for k in keys:
                        lk = k.lower()
                        if lk in lowmap:
                            v = obj.get(lowmap[lk])
                            if v:
                                return v
            except Exception:
                pass
            # 如果未找到，尝试在常见嵌套字段中寻找（book/novel/data/items first element）
            for nest_key in ('book', 'novel', 'data', 'result'):
                try:
                    nested = obj.get(nest_key)
                except Exception:
                    nested = None
                if isinstance(nested, dict):
                    v = _pick_from(nested, *keys)
                    if v:
                        return v
                elif isinstance(nested, list) and nested:
                    v = _pick_from(nested[0], *keys)
                    if v:
                        return v
            # 最后，如果 obj 本身是列表，尝试第一项
            if isinstance(obj, list) and obj:
                try:
                    return _pick_from(obj[0], *keys)
                except Exception:
                    pass
            return ''

        # title: 尝试大量候选键
        title_candidates = ('bookname', 'bookName', 'book_name', 'novelname', 'novelName', 'name', 'title', 'novelname_format', 'novelname_format_html')
        title = _pick_from(app_data, *title_candidates) or ''
        if isinstance(title, (list, dict)):
            title = str(title)
        title = html_to_text(str(title))
        book['title'] = title.strip()

        # authors: 尝试更多键名和嵌套
        author_candidates = ('authorname', 'author', 'authorName', 'authors', 'writer', 'writerName', 'author_name', 'authorNames')
        author_field = _pick_from(app_data, *author_candidates) or ''
        if isinstance(author_field, (list, dict)):
            # 如果是 list，尝试 join 或取第一个
            if isinstance(author_field, list) and author_field:
                author_str = ','.join([html_to_text(str(x)) for x in author_field])
            else:
                author_str = html_to_text(json.dumps(author_field, ensure_ascii=False))
        else:
            author_str = html_to_text(str(author_field))

        # 分割作者字符串（兼容中文分割符）
        authors = [a.strip() for a in re.split(r'[,&/;，、\s]+', author_str) if a.strip()]
        book['authors'] = authors
        book['url'] = JINJIANG_BOOK_DETAIL_WEB_URL % novelid

        # 封面
        cover_candidates = ('coverimg', 'cover', 'localImg', 'cover_img', 'bookimg')
        cover = _pick_from(app_data, *cover_candidates) or ''
        cover = str(cover)
        if cover.startswith('//'):
            cover = 'https:' + cover
        book['cover'] = cover

        # 简介
        intro_candidates = ('intro', 'novelintroshort', 'novelintro', 'description', 'desc')
        intro_html = _pick_from(app_data, *intro_candidates) or ''
        book['description_html'] = str(intro_html).strip()
        book['description'] = html_to_text(str(intro_html))

        # 标签
        category = _pick_from(app_data, 'category') or ''
        tags_raw = _pick_from(app_data, 'tags') or ''
        tags = []
        try:
            if isinstance(tags_raw, str):
                tags = [t.strip() for t in tags_raw.split(',') if t.strip()]
            elif isinstance(tags_raw, list):
                tags = [str(t).strip() for t in tags_raw if str(t).strip()]
        except Exception:
            tags = []
        if category:
            tags.insert(0, category)
        book['tags'] = tags

        # createtime -> publishedDate
        createtime = _pick_from(app_data, 'createtime', 'createTime', 'publish_time') or ''
        createtime = str(createtime).strip()
        published = ''
        try:
            if createtime.isdigit():
                ts = int(createtime)
                if ts > 1e12:
                    ts = ts / 1000
                published = datetime.fromtimestamp(ts).strftime('%Y-%m-%d')
            else:
                m = re.match(r"^(\d{4})[-/年]?(\d{1,2})?[-/月]?(\d{1,2})?", createtime)
                if m:
                    y = m.group(1)
                    mo = m.group(2) or '01'
                    d = m.group(3) or '01'
                    published = f"{y}-{int(mo):02d}-{int(d):02d}"
                else:
                    published = createtime
        except Exception:
            published = createtime
        book['publishedDate'] = published

        book['status'] = _pick_from(app_data, 'status') or ''
        book['word_count'] = _pick_from(app_data, 'wordcount', 'wordCount') or 0

        try:
            book['chapters'] = int(_pick_from(app_data, 'chapterCount', 'chaptercount', 'chapters') or 0)
        except Exception:
            book['chapters'] = None
        try:
            book['vip_start'] = int(_pick_from(app_data, 'vip_start', 'vipStart', 'vipstart') or 0)
        except Exception:
            book['vip_start'] = None

        book['source'] = {
            "id": PROVIDER_ID,
            "description": PROVIDER_NAME,
            "link": JINJIANG_BASE_URL
        }

        # 尝试拉取并合并来自 getnovelOtherInfo 的扩展信息（留言、类型、标签等）
        try:
            try:
                # 通过单独方法请求并合并额外信息
                self.fetch_and_merge_other_info(novelid, book, log, base_data=app_data)
            except Exception:
                # 不应阻塞主流程，日志调试即可
                if log:
                    log.debug('fetch_and_merge_other_info failed')
        except Exception:
            pass

        # 若关键字段缺失，记录调试信息到桌面（便于用户上报）
        if (not book['title'] or not book['authors']) and log:
            try:
                # 仅记录日志，不再写入调试文件（避免产生桌面文件）
                snippet = json.dumps(app_data, ensure_ascii=False)[:2000]
                log.warning(f'APP解析未提取到 title/author，原始 JSON 片段: {snippet}')
            except Exception:
                try:
                    log.debug('Failed to log debug snippet for missing title/author')
                except Exception:
                    pass

        return book

    def get_res_content(self, res):
        """处理响应内容（gzip+字符集）"""
        encoding = res.info().get('Content-Encoding')
        if encoding == 'gzip':
            res_content = gzip.decompress(res.read())
        else:
            res_content = res.read()
        charset = res.headers.get_content_charset() or 'utf-8'
        return res_content.decode(charset, errors='ignore')

    def get_headers(self):
        """增强请求头（模拟APP/移动端）"""
        headers = {
            'User-Agent': random_user_agent() if random.random() > 0.5 else 'JJWXC-Android/9.9.9 (Android; 10; SM-G973F)',
            'Accept-Encoding': 'gzip, deflate, br',
            'Accept': 'application/json, text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Referer': JINJIANG_M_BASE_URL if self.jinjiang_prefer_app_api else JINJIANG_BASE_URL,
            'Connection': 'keep-alive',
            'X-Requested-With': 'XMLHttpRequest'
        }
        if self.jinjiang_login_cookie:
            headers['Cookie'] = self.jinjiang_login_cookie
        return headers

    def random_sleep(self, log):
        """随机延迟（APP接口可短，网页接口需长）"""
        if self.jinjiang_prefer_app_api:
            random_sec = random.uniform(0.2, 0.8)  # APP接口延迟较短
        else:
            random_sec = random.uniform(0.5, 1.8)  # 网页接口延迟较长
        log.info(f'Random sleep: {random_sec:.2f}s')
        time.sleep(random_sec)


class JinjiangBookHtmlParser:
    """网页详情页解析器（兜底用）"""
    def __init__(self):
        self.novelid_pattern = re.compile(r"novelid=(\d+)")

    def parse_book(self, url, book_content, log):
        book = {}
        html = etree.HTML(book_content)
        if not html:
            return None

        # 书籍ID
        id_match = self.novelid_pattern.search(url)
        book['id'] = id_match.group(1) if id_match else None
        if not book['id']:
            return None

        # 书名
        title_elements = html.xpath("//h1[contains(@class, 'bookname')] | //div[contains(@class, 'novelname')]/h1")
        book['title'] = self.get_text(title_elements).strip()
        if not book['title']:
            return None

        # 作者
        author_elements = html.xpath("//a[contains(@class, 'author')] | //div[contains(@class, 'authorinfo')]//a[contains(@href, 'authorid')]")
        book['authors'] = [self.get_text(author_elements).strip()] if author_elements else []

        # 封面
        img_elements = html.xpath("//div[contains(@class, 'bookimg')]//img | //div[contains(@class, 'novelimg')]//img")
        book['cover'] = ''
        if img_elements:
            cover_src = img_elements[0].attrib.get('src', '')
            if cover_src.startswith('//'):
                cover_src = 'https:' + cover_src
            elif cover_src.startswith('/'):
                cover_src = JINJIANG_BASE_URL.rstrip('/') + cover_src
            book['cover'] = cover_src

        # 简介
        summary_elements = html.xpath("//div[contains(@class, 'intro')] | //div[@id='novelintro']")
        book['description'] = self.get_text(summary_elements, join_lines=True)

        # 标签
        tag_elements = html.xpath("//div[contains(@class, 'tag')]//a | //div[contains(@class, 'classify')]//a")
        book['tags'] = [self.get_text([elem]).strip() for elem in tag_elements if self.get_text([elem]).strip()]

        # 出版时间
        pubdate_elements = html.xpath("//div[contains(@class, 'infobox')]//span[contains(text(), '连载时间') or contains(text(), '发表时间')]")
        book['publishedDate'] = self.get_tail(pubdate_elements)

        # 来源信息
        book['url'] = url
        book['source'] = {
            "id": PROVIDER_ID,
            "description": PROVIDER_NAME,
            "link": JINJIANG_BASE_URL
        }

        return book

    def get_text(self, elements, default_str='', join_lines=False):
        texts = []
        for elem in elements:
            if isinstance(elem, etree._Element):
                text = ' '.join(elem.xpath('.//text()')).strip()
                if text:
                    texts.append(text)
        if join_lines:
            return '\n'.join(texts) if texts else default_str
        return texts[0] if texts else default_str

    def get_tail(self, elements, default_str=''):
        for elem in elements:
            if isinstance(elem, etree._Element) and elem.tail:
                tail_text = elem.tail.strip()
                if tail_text:
                    return tail_text
            next_elem = elem.getnext()
            if next_elem:
                next_text = self.get_text([next_elem]).strip()
                if next_text:
                    return next_text
        return default_str


class NewJinjiangBooks(Source):
    name = PROVIDER_NAME
    description = 'Enhanced Jinjiang Books Plugin (supports APP API, multi-type search) - 支持多类型搜索、APP接口'
    supported_platforms = ['windows', 'osx', 'linux']
    author = PROVIDER_AUTHOR
    version = PROVIDER_VERSION
    minimum_calibre_version = (5, 0, 0)
    capabilities = frozenset(['identify', 'cover'])
    # 只声明 Calibre 支持的已知字段；避免把非标准字段（如 status/word_count）放入 touched_fields
    touched_fields = frozenset([
        'title', 'authors', 'tags', 'pubdate', 'comments', 'identifier:isbn',
        'rating', 'identifier:' + PROVIDER_ID, 'publisher'
    ])
    book_searcher = None

    options = (
        Option(
            'jinjiang_concurrency_size', 'number', JINJIANG_CONCURRENCY_SIZE,
            _('Concurrency size:'),
            _('Maximum number of concurrent requests (≤5 recommended)')
        ),
        Option(
            'jinjiang_delay_enable', 'bool', True,
            _('Enable random delay:'),
            _('Avoid anti-crawling (required for web search)')
        ),
        Option(
            'jinjiang_login_cookie', 'string', None,
            _('Login cookie:'),
            _('Cookie after logging into Jinjiang (required for APP API and VIP content)')
        ),
        Option(
            'jinjiang_search_with_author', 'bool', False,
            _('Search with author:'),
            _('Add author name to search keywords (improve accuracy)')
        ),
        Option(
            'jinjiang_prefer_app_api', 'bool', True,
            _('Prefer APP API:'),
            _('Use APP API first (more stable, less anti-crawling)')
        ),
    )

    def __init__(self, *args, **kwargs):
        Source.__init__(self, *args, **kwargs)
        concurrency_size = int(self.prefs.get('jinjiang_concurrency_size', JINJIANG_CONCURRENCY_SIZE))
        jinjiang_delay_enable = bool(self.prefs.get('jinjiang_delay_enable', True))
        jinjiang_login_cookie = self.prefs.get('jinjiang_login_cookie', None)
        jinjiang_search_with_author = bool(self.prefs.get('jinjiang_search_with_author', False))
        jinjiang_prefer_app_api = bool(self.prefs.get('jinjiang_prefer_app_api', True))
        
        self.book_searcher = JinjiangBookSearcher(
            concurrency_size=concurrency_size,
            jinjiang_delay_enable=jinjiang_delay_enable,
            jinjiang_login_cookie=jinjiang_login_cookie,
            jinjiang_search_with_author=jinjiang_search_with_author,
            jinjiang_prefer_app_api=jinjiang_prefer_app_api
        )

    def get_book_url(self, identifiers):
        jinjiang_id = identifiers.get(PROVIDER_ID, None)
        if jinjiang_id:
            return PROVIDER_ID, jinjiang_id, JINJIANG_BOOK_DETAIL_WEB_URL % jinjiang_id
        return None

    def identify(self, log, result_queue, abort, title=None, authors=None, identifiers={}, timeout=30):
        log.info(f'Jinjiang identify: title={title}, authors={authors}, identifiers={identifiers}')

        # 优先ID查询
        book_url_info = self.get_book_url(identifiers)
        if book_url_info:
            provider_id, book_id, url = book_url_info
            log.info(f'Query by ID: {book_id}')
            book = self.book_searcher.load_book(url, log)
            books = [book] if book else []
        else:
            if not title and not authors:
                log.warning('No title or authors provided')
                return

            # 清洗并归一化查询词以提高匹配率
            cleaned_title = normalize_query(title) if title else ''
            cleaned_authors = [normalize_query(a) for a in authors] if authors else []

            # 先用 title(+author when enabled) 搜索并记录耗时和结果数
            t0 = time.time()
            books = self.book_searcher.search_books(query=cleaned_title or ' '.join(cleaned_authors), authors=authors, log=log)
            elapsed = time.time() - t0
            log.info(f'Found {len(books)} results from Jinjiang (time: {elapsed:.3f}s)')

            # 若未命中，先尝试作者搜索（晋江的JSON规则：#作者# 表示作者搜索）
            if not books and cleaned_authors:
                t1 = time.time()
                author_query = ' '.join(cleaned_authors)
                wrapped = f"#{author_query}#"
                log.info(f'No results for title-search, retrying with author-only (wrapped): {wrapped}')
                books = self.book_searcher.search_books(query=wrapped, authors=authors, log=log)
                elapsed2 = time.time() - t1
                log.info(f'Author-only search found {len(books)} results (time: {elapsed2:.3f}s)')

            # 仍未命中时，尝试生成若干短查询变体（去掉'完结','番外'等标注，或使用最长词）
            if not books and cleaned_title:
                variations = generate_title_variations(cleaned_title)
                for var in variations:
                    t2 = time.time()
                    log.info(f'Trying title variation: {var}')
                    books = self.book_searcher.search_books(query=var, authors=authors, log=log)
                    elapsed3 = time.time() - t2
                    log.info(f'Variation {var} found {len(books)} results (time: {elapsed3:.3f}s)')
                    if books:
                        break

        for book in books:
            if abort.is_set():
                break
            if book:
                metadata = self.to_metadata(book, log)
                if isinstance(metadata, Metadata):
                    # cache cover url if present
                    try:
                        dbid = metadata.identifiers.get(PROVIDER_ID)
                        if metadata.cover and dbid:
                            try:
                                # store cover URL mapping so Calibre can download later
                                self.cache_identifier_to_cover_url(dbid, metadata.cover)
                            except Exception:
                                log.debug('cache_identifier_to_cover_url failed')
                    except Exception:
                        pass

                    # allow Calibre to clean/normalize the metadata before returning
                    try:
                        self.clean_downloaded_metadata(metadata)
                    except Exception:
                        log.debug('clean_downloaded_metadata failed')

                    result_queue.put(metadata)

    # browse 能力已移除以简化插件为仅按书名/作者提取元数据

    def to_metadata(self, book, log):
        mi = Metadata(book['title'], book['authors'])
        mi.identifiers = {PROVIDER_ID: book['id']}
        mi.url = book['url']
        # 封面：保留封面 URL 到 mi.cover（Calibre 接受 URL 字符串）并缓存 URL 供 download_cover 使用
        mi.cover = book.get('cover', None)
        if mi.cover:
            try:
                self.cache_identifier_to_cover_url(book['id'], mi.cover)
            except Exception:
                log.debug('Cache cover URL failed')
        
        # 简介（已转换为纯文本）
        mi.comments = book.get('description', '') or book.get('description_html', '')
        
        # 标签
        if book.get('tags'):
            mi.tags = book['tags']
        
        # 出版日期
        pubdate_str = book.get('publishedDate')
        if pubdate_str:
            try:
                pubdate_str = pubdate_str.replace('年', '-').replace('月', '-').replace('日', '')
                if re.match(r'^\d{4}-\d{2}-\d{2}$', pubdate_str):
                    mi.pubdate = datetime.strptime(pubdate_str, '%Y-%m-%d')
                elif re.match(r'^\d{4}-\d{2}$', pubdate_str):
                    mi.pubdate = datetime.strptime(pubdate_str, '%Y-%m')
                elif re.match(r'^\d{4}$', pubdate_str):
                    mi.pubdate = datetime.strptime(pubdate_str, '%Y')
            except Exception as e:
                log.warning(f'Parse pubdate failed: {e}')
        
        # 新增字段（来自APP接口）
        mi.set('status', book.get('status', ''))  # 连载状态
        mi.set('word_count', book.get('word_count', 0))  # 字数
        # 保留原始 HTML 简介以便需要时使用
        if book.get('description_html'):
            mi.set('description_html', book.get('description_html'))
        # 章节与 VIP 信息
        if book.get('chapters') is not None:
            mi.set('chapters', book.get('chapters'))
        if book.get('vip_start') is not None:
            mi.set('vip_start', book.get('vip_start'))
        # 语言
        try:
            mi.language = 'zh_CN'
        except Exception:
            try:
                mi.set('language', 'zh_CN')
            except Exception:
                log.debug('Failed to set language')
        # 评分（若存在）
        if book.get('rating') is not None:
            try:
                mi.rating = float(book.get('rating'))
            except Exception:
                pass
        # ISBN/Series（占位，如果返回再写入）
        if book.get('isbn'):
            try:
                mi.isbn = book.get('isbn')
            except Exception:
                pass
        if book.get('series'):
            try:
                mi.series = book.get('series')
            except Exception:
                pass
        
        mi.source = book['source']['description']
        # 如果元数据来自晋江 APP/网页，则统一设置出版社为“晋江文学城”
        try:
            mi.publisher = '晋江文学城'
        except Exception:
            try:
                mi.set('publisher', '晋江文学城')
            except Exception:
                log.debug('Failed to set publisher field')
        return mi

    def download_cover(self, log, result_queue, abort, title=None, authors=None, identifiers={}, timeout=30, get_best_cover=False):
        cached_url = self.get_cached_cover_url(identifiers)
        if not cached_url:
            log.info('No cached cover, run identify first')
            rq = Queue()
            self.identify(log, rq, abort, title=title, authors=authors, identifiers=identifiers)
            if abort.is_set():
                return
            
            results = []
            while True:
                try:
                    results.append(rq.get_nowait())
                except Empty:
                    break
            
            for mi in results:
                cached_url = self.get_cached_cover_url(mi.identifiers)
                if cached_url:
                    break
        
        if not cached_url:
            log.info('No cover found')
            return
        
        log.info(f'Download cover: {cached_url}')
        try:
            br = self.browser
            if self.book_searcher.jinjiang_login_cookie:
                br = br.clone_browser()
                br.set_current_header('Cookie', self.book_searcher.jinjiang_login_cookie)
            br.set_current_header('Referer', JINJIANG_BASE_URL)
            br.set_current_header('User-Agent', random_user_agent())
            
            cdata = br.open_novisit(cached_url, timeout=timeout).read()
            if cdata:
                result_queue.put((self, cdata))
        except Exception as e:
            log.error(f'Download cover failed: {e}')

    def get_cached_cover_url(self, identifiers):
        jinjiang_id = identifiers.get(PROVIDER_ID)
        if not jinjiang_id:
            return None
        return self.cached_identifier_to_cover_url(jinjiang_id)


# 测试代码
if __name__ == "__main__":
    try:
        from calibre.ebooks.metadata.sources.test import test_identify_plugin, title_test, authors_test
    except Exception:
        # Calibre test harness not available in this environment; skip local tests
        print('Calibre test harness not available, skipping tests')
    else:
        test_identify_plugin(
            NewJinjiangBooks.name,
            [
                (
                    {
                        'title': '#酱子贝#',  # 作者搜索（JSON规则）
                        'authors': [],
                        'identifiers': {}
                    },
                    [
                        title_test('我行让我上[电竞]', exact=False),
                        authors_test(['酱子贝'])
                    ]
                ),
                (
                    {
                        'title': '我喜欢你的信息素',
                        'authors': ['引路星'],
                        'identifiers': {}
                    },
                    [
                        title_test('我喜欢你的信息素', exact=True),
                        authors_test(['引路星'])
                    ]
                )
            ]
        )